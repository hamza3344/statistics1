﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace statistics1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //mean
            double sum = 0;
            string[] values = textBox1.Text.Split(",");
            foreach(string s in values)
            {
                sum = sum + Convert.ToInt64(s);
            }
            double avg = sum / values.Length;
            MessageBox.Show("Average " + avg);
            //median
            List<double> medianlist = new List<double>();
            foreach (string s in values)
            {
                medianlist.Add(Convert.ToInt64(s));
            }
            double med = 0;
            medianlist.Sort();
            int x = medianlist.Count / 2;
            if(medianlist.Count%2==0)
            {
                med = (medianlist[x - 1] + medianlist[x]) / 2;
            }else
            {
                med = medianlist[x];
            }
            MessageBox.Show("Median " + med.ToString());
            //mode
            var mode = medianlist.GroupBy(i => i).OrderByDescending(grp => grp.Count()).Select(grp => grp.Key).First();
            MessageBox.Show("mode " + mode.ToString());

        }
    }
}
